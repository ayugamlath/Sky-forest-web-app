import React from 'react'

const toolbar=()=> {
  return (
    <div className='tool-bar'>
        <div className='burger'>
        
        </div>
        <div className='title'>the</div>
    </div>
  )
}

export default toolbar

