import React from 'react'

const About = () => {
  return (
    <div>
      this is sbout one
    </div>
  )
}

export default About
